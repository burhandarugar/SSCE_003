package com.jap.areacalculator;

import java.util.Scanner;

public class AreaCalculator 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select an option from list to calculate area of fence");
        System.out.println("1. Square area for the chickens");
        System.out.println("2. Circular area for ducks");
        System.out.println("3. Rectangular area for cows");
        System.out.println();
        // Input choice from user
        int choice = scanner.nextInt();
        calculateAreaOfFence(choice);
        scanner.close();

    }

    // Function to calculate area of fence by calling respective methods according to user's choice
    public static void calculateAreaOfFence(int choice) 
    {
    	double side =5;
    	double radius =-9.3;
    	double length =10;
    	double breadth = 10;
    	double area=0;
    	
    	switch(choice)
        {
           case 1:area=calculateAreaOfSquare(side);
                  break;
           case 2:area=calculateAreaOfCircle(radius);
                  break;
           case 3:area=calculateAreaOfRectangle(length,breadth);
                  break;     
          
        }
    	System.out.println(area);

    }
    public static double calculateAreaOfSquare(double side) 
    {
        return (Math.pow(side,2));
    }

    public static double calculateAreaOfCircle(double radius) 
    {
    	final double PI=3.142857;
        return (PI*Math.pow(radius,2));
    }

    public static double calculateAreaOfRectangle(double length, double breadth) 
    {
        return (length*breadth);
    }
}
